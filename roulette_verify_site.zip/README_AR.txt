ملفات صفحة التحقق الخاصة ببوت الروليت

1) ارفع محتويات هذا المجلد إلى مستودع GitHub جديد (يفضل Private).
2) في Render اختر New > Web Service ثم اربط مستودع GitHub.
3) Build Command: pip install -r requirements.txt
4) Start Command: gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 4
5) أضف متغيرات البيئة التالية في Render:
   BOT_TOKEN = توكن البوت نفسه (لا ترسله لأحد)
   WEB_VERIFY_SECRET = كلمة سر طويلة عشوائية مشتركة بين Render وWispbyte
   TURNSTILE_SITE_KEY = مفتاح الموقع من Cloudflare Turnstile
   TURNSTILE_SECRET_KEY = مفتاح السر من Cloudflare Turnstile
6) بعد النشر انسخ رابط Render الذي ينتهي بـ onrender.com.
7) في Cloudflare Turnstile أضف اسم المضيف فقط، مثال: roulette-human-verification.onrender.com
   لا تكتب https:// ولا مسار الصفحة.
8) في Wispbyte أضف متغيري البيئة إلى البوت:
   WEB_VERIFY_URL = https://اسم-الخدمة.onrender.com
   WEB_VERIFY_SECRET = نفس قيمة WEB_VERIFY_SECRET التي وضعتها في Render
9) أعد تشغيل البوت.

مهم:
- لا تضع BOT_TOKEN أو مفاتيح Cloudflare داخل ملفات GitHub.
- لا تشارك WEB_VERIFY_SECRET مع أحد.
- رابط Render المجاني قد ينام عند عدم الاستخدام وقد يتأخر أول فتح بعد النوم.
- يجب فتح صفحة التحقق من زر Web App داخل المحادثة الخاصة مع البوت، وليس من متصفح عادي.
